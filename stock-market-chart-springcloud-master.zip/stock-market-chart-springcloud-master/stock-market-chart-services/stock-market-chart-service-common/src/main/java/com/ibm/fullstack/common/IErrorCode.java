package com.ibm.fullstack.common;

public interface IErrorCode {
    long getCode();

    String getMsg();
}
