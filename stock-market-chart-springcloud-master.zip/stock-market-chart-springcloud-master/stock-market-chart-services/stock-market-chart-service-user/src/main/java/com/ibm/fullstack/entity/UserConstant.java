package com.ibm.fullstack.entity;

public class UserConstant {

    public static final String USER_TYPE_ADMIN = "admin";
    public static final String USER_TYPE_USER = "user";
}
